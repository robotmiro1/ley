var searchData=
[
  ['person_5fx',['person_x',['../namespaceassignment.html#a7e8526eaa3668ae27bc604c41971baf7',1,'assignment']]],
  ['person_5fy',['person_y',['../namespaceassignment.html#aad163536a545f4ecc6ad14a367374cf5',1,'assignment']]]
];
