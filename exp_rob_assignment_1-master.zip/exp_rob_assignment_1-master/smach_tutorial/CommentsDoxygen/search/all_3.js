var searchData=
[
  ['gesture_5fx',['gesture_x',['../classassignment_1_1_play.html#af53f67508f0689ba60ec3250e43bc7e6',1,'assignment::Play']]],
  ['gesture_5fy',['gesture_y',['../classassignment_1_1_play.html#a096cb383bd9592a5c4e5f8938746f5a8',1,'assignment::Play']]]
];
