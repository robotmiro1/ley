var searchData=
[
  ['normal',['Normal',['../classassignment_1_1_normal.html',1,'assignment']]]
];
