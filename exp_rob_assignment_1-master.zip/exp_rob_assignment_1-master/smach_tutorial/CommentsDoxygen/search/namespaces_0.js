var searchData=
[
  ['assignment',['assignment',['../namespaceassignment.html',1,'']]]
];
